<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title>AdminLTE </title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport" />

  <style>
    .row {
      display: flex;
    }

    .col {
      width: 50%;
    }

    ..canvas_div_pdf {
      width: 1450px;
      position: fixed;
      left: -100%;
    }
  </style>
</head>

<body>
  <div class="canvas_div_pdf">
    <div class="container-fluid">
      <div class="row">
        <div class="col">
          <canvas id="cptrendsChart"></canvas>
        </div>
        <div class="col">
          <canvas id="cptrendsChart1"></canvas>
        </div>
      </div>
    </div>
  </div>
  <button onclick="getPDF()">Download PDF</button>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>
  <script src="jspdf.min.js"></script>
  <script src="html2canvas.js"></script>

  <script>
    Chart.defaults.font.size = 9;

    var data = {
      labels: [
        "w1",
        "w3",
        "w1",
        "w3",
        "w1",
        "w3",
        "w1",
        "w3",
        "w1",
        "w3",
        "w1",
        "w3",
      ],
      datasets: [{
          label: "y",
          data: [0.8, 0.6, 0.4, 0.2, 0.0, -0.2, -0.4, -0.6],
          borderColor: "transparent",
          fill: false,
        },
        {
          label: "points",
          data: [0.5, 0.5, 0.5, 0.5, 0.6, 0.5, 0.6, 0.5],
          borderColor: "grey",
          fill: false,
        },
      ],
    };

    var ctx = document.getElementById("cptrendsChart").getContext("2d");
    var cptrendsChart = new Chart(ctx, {
      type: "line",
      data: data,
    });

    var data1 = {
      labels: [
        "w1",
        "w3",
        "w1",
        "w3",
        "w1",
        "w3",
        "w1",
        "w3",
        "w1",
        "w3",
        "w1",
        "w3",
      ],
      datasets: [{
          label: "y",
          data: [0.8, 0.6, 0.4, 0.2, 0.0, -0.2, -0.4, -0.6],
          borderColor: "transparent",
          fill: false,
        },
        {
          label: "points",
          data: [0.5, 0.5, 0.5, 0.5, 0.6, 0.5, 0.6, 0.5],
          borderColor: "grey",
          fill: false,
        },
      ],
    };

    var ctx1 = document.getElementById("cptrendsChart1").getContext("2d");
    var cptrendsChart1 = new Chart(ctx1, {
      type: "line",
      data: data1,
    });

  </script>


<script>
    function getPDF() {
      var HTML_Width = $(".canvas_div_pdf").width();
      var HTML_Height = $(".canvas_div_pdf").height();
      var top_left_margin = 15;
      var PDF_Width = HTML_Width + (top_left_margin * 2);
      var PDF_Height = (PDF_Width * 1.5) + (top_left_margin * 2);
      var canvas_image_width = HTML_Width;
      var canvas_image_height = HTML_Height;

      var totalPDFPages = Math.ceil(HTML_Height / PDF_Height) - 1;


      html2canvas($(".canvas_div_pdf")[0], {
        allowTaint: true
      }).then(function(canvas) {
        canvas.getContext('2d');

        console.log(canvas.height + "  " + canvas.width);


        var imgData = canvas.toDataURL("image/jpeg", 1.0);
        var pdf = new jsPDF('p', 'pt', [PDF_Width, PDF_Height]);
        pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin, canvas_image_width, canvas_image_height);


        for (var i = 1; i <= totalPDFPages; i++) {
          pdf.addPage(PDF_Width, PDF_Height);
          pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height * i) + (top_left_margin * 4), canvas_image_width, canvas_image_height);
        }

        pdf.save("HTML-Document.pdf");
      });
    };
  </script>

  

</body>

</html>